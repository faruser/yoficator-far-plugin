#include <wchar.h>
using namespace std;

#include "far_tools.hpp"

#include "yoficator.hpp"
#include "options.hpp"
#include "lng.hpp"


int WINAPI
ConfigureW (int /*ItemNumber*/)
{
    const int SCREEN_X = FarTools::GetScreenWidth () ? FarTools::GetScreenWidth () : 80;
//  const int SCREEN_Y = FarTools::GetScreenHeight () ? FarTools::GetScreenHeight () : 25;

    const int MAX_DLG_X = SCREEN_X - 8;
    const int MAX_DLG_Y = 14;


    FarDialogItem DlgDoubleBox       = { DI_DOUBLEBOX, 3, 1, MAX_DLG_X-4, MAX_DLG_Y-2,
                                         FALSE, {0}, 0,               0, FarTools::GetMsg (MConfigureTitle), 0 };

    FarDialogItem DlgDictFileLbl     = { DI_TEXT,      5, 2, MAX_DLG_X-6, 2, 
                                         FALSE, {0}, 0,               0, FarTools::GetMsg (MCnfDictionary),  0 };
    FarDialogItem DlgDictFile        = { DI_EDIT,      5, 3, MAX_DLG_X-6, 3, 
                                         TRUE,  {0}, 0,               0, 0,                        0 };
    FarDialogItem DlgUserDictFileLbl = { DI_TEXT,      5, 5, MAX_DLG_X-6, 5, 
                                         FALSE, {0}, 0,               0, FarTools::GetMsg (MCnfUserDictionary), 0 };
    FarDialogItem DlgUserDictFile    = { DI_EDIT,      5, 6, MAX_DLG_X-6, 6, 
                                         TRUE,  {0}, 0,               0, 0,                        0 };

    FarDialogItem DlgConfirmAll      = { DI_CHECKBOX, 12, 8,  0, 8,
                                         FALSE, {0}, 0,               0, FarTools::GetMsg (MCnfConfirmAll),  0 };
    FarDialogItem DlgCheckExist      = { DI_CHECKBOX, 12, 9,  0, 9,
                                         FALSE, {0}, 0,               0, FarTools::GetMsg (MCnfCheckExist),  0 };

    FarDialogItem DlgOk              = { DI_BUTTON,    0, MAX_DLG_Y-3, 0, MAX_DLG_Y-3,
                                         FALSE, {0}, DIF_CENTERGROUP, 0, L"Ok",                    0 };
    FarDialogItem DlgCancel          = { DI_BUTTON,    0, MAX_DLG_Y-3, 0, MAX_DLG_Y-3,
                                         FALSE, {0}, DIF_CENTERGROUP, 0, L"Cancel",                0 };

    FarDialogItem ConfigDialog[] = {
        DlgOk               // 0
      , DlgCancel           // 1

      , DlgDictFile         // 2
      , DlgUserDictFile     // 3
      , DlgConfirmAll       // 4
      , DlgCheckExist       // 5

      , DlgDoubleBox        // 6
      , DlgDictFileLbl      // 7
      , DlgUserDictFileLbl  // 8
    };


    HANDLE hDlg = FarTools::Info.DialogInit(FarTools::Info.ModuleNumber, -1, -1, MAX_DLG_X, MAX_DLG_Y, FarTools::GetMsg (MConfigureHelp),
                                ConfigDialog, sizeof(ConfigDialog)/sizeof(ConfigDialog[0]), 0, 0, /*DlgProc*/0, 0);
    if (hDlg != INVALID_HANDLE_VALUE)
    {
        Opt.Read ();

        FarDialogItemData dict_file_item = { wcslen (Opt.dict_file), Opt.dict_file };
        FarTools::Info.SendDlgMessage(hDlg, DM_SETTEXT, 2/*DlgDictFile*/, (LONG_PTR)&dict_file_item);
        FarDialogItemData user_dict_file_item = { wcslen (Opt.user_dict_file), Opt.user_dict_file };
        FarTools::Info.SendDlgMessage(hDlg, DM_SETTEXT, 3/*DlgUserDictFile*/, (LONG_PTR)&user_dict_file_item);

        FarTools::Info.SendDlgMessage(hDlg, DM_SETCHECK, 4/*DlgConfirmAll*/, Opt.confirm_all ? BSTATE_CHECKED : BSTATE_UNCHECKED);
        FarTools::Info.SendDlgMessage(hDlg, DM_SETCHECK, 5/*DlgCheckExist*/, Opt.check_exist ? BSTATE_CHECKED : BSTATE_UNCHECKED);


        int ExitCode = FarTools::Info.DialogRun (hDlg);

        if (ExitCode == 1) // ����� �� Cancel (��. ���� ����� ������ Cancel � ConfigDialog)
        {
            FarTools::Info.DialogFree (hDlg);
            return FALSE;
        }

{
        // ��������� SendDlgMessage(DM_GETTEXTLENGTH) � SendDlgMessage(DM_GETTEXTPTR)
        size_t len = FarTools::Info.SendDlgMessage (hDlg, DM_GETTEXTLENGTH, 2/*DlgDictFile*/, 0);
        wchar_t *str = new wchar_t [len+1];
        FarTools::Info.SendDlgMessage (hDlg, DM_GETTEXTPTR, 2/*DlgDictFile*/, (LONG_PTR)str);
        // path � ������ ��� �������������. ��������� DM_GETCONSTTEXTPTR.
        wcscpy (Opt.dict_file, str);
        delete str;
}
{
        // ��������� SendDlgMessage(DM_GETTEXTLENGTH) � SendDlgMessage(DM_GETTEXTPTR)
        size_t len = FarTools::Info.SendDlgMessage (hDlg, DM_GETTEXTLENGTH, 3/*DlgUserDictFile*/, 0);
        wchar_t *str = new wchar_t [len+1];
        FarTools::Info.SendDlgMessage (hDlg, DM_GETTEXTPTR, 3/*DlgUserDictFile*/, (LONG_PTR)str);
        // path � ������ ��� �������������. ��������� DM_GETCONSTTEXTPTR.
        wcscpy (Opt.user_dict_file, str);
        delete str;
}

        Opt.confirm_all = FarTools::Info.SendDlgMessage (hDlg, DM_GETCHECK, 4/*DlgConfirmAll*/, 0);
        Opt.check_exist = FarTools::Info.SendDlgMessage (hDlg, DM_GETCHECK, 5/*DlgCheckExist*/, 0);

        Opt.Write ();

        FarTools::Info.DialogFree (hDlg);
    }


    return TRUE;
}
