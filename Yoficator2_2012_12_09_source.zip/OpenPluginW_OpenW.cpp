#include "yoficator.hpp"
#include "far_tools.hpp"
#include "options.hpp"
#include "lng.hpp"


HANDLE WINAPI
#if FARMANAGERVERSION_MAJOR==3
// http://www.farmanager.com/svn/trunk/enc/enc_rus3.work/meta/exported_functions/openw.html
OpenW (const struct OpenInfo *OInfo)
#elif FARMANAGERVERSION_MAJOR==2
OpenPluginW (int /*OpenFrom*/, INT_PTR /*Item*/)
#endif

{

#if FARMANAGERVERSION_MAJOR==3
    if (OInfo->StructSize < sizeof(OpenInfo)) 
        return INVALID_HANDLE_VALUE;
#endif

    // ������ ��������
    Opt.Read ();
    if (Opt.dict_file[0] == 0 && Opt.user_dict_file[0] == 0)
    {
        FarTools::MsgError (FarTools::GetMsg (MPluginName), NULL, FarTools::GetMsg (MErrorDictionariesDoesNotSet));
        return INVALID_HANDLE_VALUE;
    }

    yoficator ();

    FarEditor::SetTitle (0);
    FarEditor::Redraw ();

    return INVALID_HANDLE_VALUE;
}
