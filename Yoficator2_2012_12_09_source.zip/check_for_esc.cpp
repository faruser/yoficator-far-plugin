#include "yoficator.hpp"
#include "far.hpp"


bool
check_for_esc (void)
{
    HANDLE hConInp = GetStdHandle (STD_INPUT_HANDLE);

    while (1)
    {
        INPUT_RECORD rec;
        DWORD ReadCount;

        PeekConsoleInputW (hConInp, &rec, 1, &ReadCount);

        if (0 == ReadCount)
            break;

        ReadConsoleInputW (hConInp, &rec, 1, &ReadCount);

        if (KEY_EVENT == rec.EventType)
            if (rec.Event.KeyEvent.wVirtualKeyCode == VK_ESCAPE && rec.Event.KeyEvent.bKeyDown)
            {
/*
                const wchar_t *Msg[2];
                Msg[0] = GetMsg (MPluginName);
                Msg[1] = L"Exit?";
                if (0 ==
#if FARMANAGERVERSION_MAJOR==3
                    Info.Message (&MainGuid, nullptr, FMSG_WARNING|FMSG_MB_YESNO, NULL, Msg, ARRAYSIZE(Msg), 0)
#elif FARMANAGERVERSION_MAJOR==2
                    Info.Message (Info.ModuleNumber, FMSG_WARNING|FMSG_MB_YESNO, NULL, Msg, sizeof(Msg)/sizeof(Msg[0]), 0)
#endif
                )
*/
                    return true;
            }
    }

    return false;
}
