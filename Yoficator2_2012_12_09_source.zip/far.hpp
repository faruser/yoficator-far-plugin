#ifndef __DEFINE__FAR__H__
#define __DEFINE__FAR__H__

#include "C:\Program Files\Far2\PluginSDK\Headers.c\plugin.hpp"

// ��� ������� � HKCU\Software\Far<>\Plugins
#define REG_PLUGIN_NAME_FAR (L"\\Yoficat")

#endif
