#include <initguid.h>
#include "far_tools.hpp"


////////////////////////////////////////////////////////////////////////


PluginStartupInfo FarTools::Info;
FarStandardFunctions FarTools::FSF;


////////////////////////////////////////////////////////////////////////
// Far 2 ������ ��������� �������� � ������� Windows
#if FARMANAGERVERSION_MAJOR==2

const wchar_t *
GetSubKey (void)
{
    // ������� ����� ����� strBuf �� ���������� �������� Info.RootKey � ����� ������� REG_PLUGIN_NAME_FAR2
    static wchar_t strBuf[512];
    if (wcslen (FarTools::Info.RootKey) > 512 - 1)
        return 0;

    wcscpy (strBuf, FarTools::Info.RootKey);
    if (wcslen (FarTools::Info.RootKey) > 512 - wcslen (strBuf) + 1)
        return 0;

    wcscat (strBuf, REG_PLUGIN_NAME_FAR);
    return strBuf;
}


LONG
CreateKey (HKEY *hKey)
{
    const wchar_t * strBuf = GetSubKey ();
    if (!strBuf) return false;

    HKEY local_hKey;
    LONG res = RegCreateKeyExW (HKEY_CURRENT_USER              // hKey
                              , strBuf                         // lpSubKey
                              , 0                              // Reserved
                              , NULL                           // lpClass
                              , REG_OPTION_NON_VOLATILE        // dwOptions
                              , DELETE | KEY_READ | KEY_WRITE  // samDesired
                              , NULL                           // lpSecurityAttributes
                              , &local_hKey                    // phkResult
                              , NULL                           // lpdwDisposition
               );

    if (res == ERROR_SUCCESS /*&& hKey != 0*/)
        *hKey = local_hKey;

    return res;
}

LONG
OpenKey (HKEY *hKey)
{
    const wchar_t * strBuf = GetSubKey ();
    if (!strBuf) return ERROR_NOT_ENOUGH_MEMORY;

    HKEY local_hKey;
    LONG res = RegOpenKeyExW (HKEY_CURRENT_USER  // hKey
                            , strBuf             // lpSubKey
                            , 0                  // ulOptions
                            , KEY_READ           // samDesired
                            , &local_hKey        // phkResult
               );

    if (res == ERROR_SUCCESS /*&& hKey != 0*/)
    {
        *hKey = local_hKey;
    }

    return res;
}


bool
SetRegKey (const wchar_t * lpValueName, const bool value)
{
    HKEY hKey;
    LONG res = CreateKey (&hKey);
    if (res != ERROR_SUCCESS)
        return false;

    DWORD bool_value;
    bool_value = value;
    res = RegSetValueExW (hKey, lpValueName, 0, REG_DWORD, (const BYTE *)&bool_value, sizeof(bool_value));
    RegCloseKey (hKey);

    if (res != ERROR_SUCCESS)
        return false;

    return true;
}

bool
SetRegKey (const wchar_t * lpValueName, const wchar_t * value)
{
    HKEY hKey;
    LONG res = CreateKey (&hKey);
    if (res != ERROR_SUCCESS)
        return false;

    res = RegSetValueExW (hKey, lpValueName, 0, REG_SZ, (const BYTE *)value, (wcslen(value) + 1/*��� ������������ \0*/) * sizeof(wchar_t));
    RegCloseKey (hKey);

    if (res != ERROR_SUCCESS)
        return false;

    return true;
}

void
GetRegKey (const wchar_t * lpValueName, bool *value, const bool def)
{
    HKEY hKey;
    LONG res = OpenKey (&hKey);
    if (res != ERROR_SUCCESS)
    {
        *value = def;
    }
    else
    {
        DWORD bool_value = 0;
        DWORD dataLen = sizeof (DWORD);
        res = RegQueryValueExW (hKey
                              , lpValueName
                              , 0 
                              , NULL/*REG_DWORD*/
                              , (BYTE*)&bool_value
                              , &dataLen
              );
        RegCloseKey (hKey);
        if (res != ERROR_SUCCESS)
        {
            *value = def;
        }
        else
        {
            *value = bool_value;
        }
    }
}

void
GetRegKey (const wchar_t * lpValueName, wchar_t *value, const size_t mx, const wchar_t *def)
{
    HKEY hKey;
    LONG res = OpenKey (&hKey);
    if (res != ERROR_SUCCESS)
    {
        if (def)
        {
            wcsncpy (value, def, mx);
        }
        else
        {
            *value = 0;
        }
    }
    else
    {
        wchar_t *t = new wchar_t[mx + 1];
        if (!t)
        {
            if (def) wcsncpy (value, def, mx); else *value = 0;
        }
        else
        {
            DWORD lpcbData = mx * 2;  // *2 - from wchar_t to byte :)
            res = RegQueryValueExW (hKey          // HKEY hKey
                                  , lpValueName   // LPCTSTR lpValueName
                                  , 0             // LPDWORD lpReserved
                                  , /*&lpType*/0  // LPDWORD lpType
                                  , (LPBYTE)t     // LPBYTE lpData
                                  , &lpcbData     // LPDWORD lpcbData
                  );
            if (res != ERROR_SUCCESS)
            {
                if (def)
                {
                    wcsncpy (value, def, mx);
                }
                else
                {
                    *value = 0;
                }
            }
            else
            {
                wcsncpy (value, t, mx);
            }

            delete[] t;
        }
    }

    RegCloseKey (hKey);

    value[mx-1] = 0;
//  value[mx-2] = 0;
}

#endif  // FARMANAGERVERSION_MAJOR==2


////////////////////////////////////////////////////////////////////////


const wchar_t *
FarTools::GetMsg (const int message_id)
{
#if FARMANAGERVERSION_MAJOR==3
    return FarTools::Info.GetMsg (&MainGuid, message_id);
#elif FARMANAGERVERSION_MAJOR==2
    return FarTools::Info.GetMsg (FarTools::Info.ModuleNumber, message_id);
#endif
}


int
FarTools::GetScreenHeight (void)
{
    SMALL_RECT small_rect;

    if (TRUE ==
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.AdvControl (&MainGuid, ACTL_GETFARRECT, 0, &small_rect)
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.AdvControl (FarTools::Info.ModuleNumber, ACTL_GETFARRECT, &small_rect)
#endif
    )
        return small_rect.Bottom - small_rect.Top + 1;
    else
        return 0;
}

int
FarTools::GetScreenWidth (void)
{
    SMALL_RECT small_rect;

    if (TRUE ==
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.AdvControl (&MainGuid, ACTL_GETFARRECT, 0, &small_rect)
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.AdvControl (FarTools::Info.ModuleNumber, ACTL_GETFARRECT, &small_rect)
#endif
    )
        return small_rect.Right - small_rect.Left + 1;
    else
        return 0;
}


int
FarTools::Menu (const int X, const int Y, const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2)
{
    struct FarMenuItem MenuItems[2];
    memset (MenuItems, 0, sizeof (MenuItems));

    MenuItems[0].Text = S1;
    MenuItems[1].Text = S2;

    int MenuCode =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.Menu (&MainGuid, nullptr, X, Y, 0, FMENU_WRAPMODE, Title, NULL, HelpTopic, NULL, NULL, MenuItems, ARRAYSIZE(MenuItems))
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.Menu (FarTools::Info.ModuleNumber, X, Y, 0, FMENU_WRAPMODE, Title, NULL, HelpTopic, NULL, NULL, MenuItems, sizeof (MenuItems) / sizeof (MenuItems[0]))
#endif
    ;

    return MenuCode;
}

int
FarTools::Menu (const int X, const int Y, const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2, const wchar_t * S3, const wchar_t * S4)
{
    struct FarMenuItem MenuItems[4];
    memset (MenuItems, 0, sizeof (MenuItems));

    MenuItems[0].Text = S1;
    MenuItems[1].Text = S2;
    MenuItems[2].Text = S3;
    MenuItems[3].Text = S4;

    int MenuCode =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.Menu (&MainGuid, nullptr, X, Y, 0, FMENU_WRAPMODE, Title, NULL, HelpTopic, NULL, NULL, MenuItems, ARRAYSIZE(MenuItems))
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.Menu (FarTools::Info.ModuleNumber, X, Y, 0, FMENU_WRAPMODE, Title, NULL, HelpTopic, NULL, NULL, MenuItems, sizeof (MenuItems) / sizeof (MenuItems[0]))
#endif
    ;

    return MenuCode;
}


int
FarTools::MsgError (const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1)
{
    const wchar_t *Msg[2];
    Msg[0] = Title;
    Msg[1] = S1;

    return
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.Message (&MainGuid, nullptr, FMSG_WARNING|FMSG_MB_OK, HelpTopic, Msg, ARRAYSIZE(Msg), 0);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.Message (FarTools::Info.ModuleNumber, FMSG_WARNING|FMSG_MB_OK, HelpTopic, Msg, sizeof(Msg)/sizeof(Msg[0]), 0);
#endif
}

int
FarTools::MsgError (const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2)
{
    const wchar_t *Msg[3];
    Msg[0] = Title;
    Msg[1] = S1;
    Msg[1] = S2;

    return
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.Message (&MainGuid, nullptr, FMSG_WARNING|FMSG_MB_OK, HelpTopic, Msg, ARRAYSIZE(Msg), 0);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.Message (FarTools::Info.ModuleNumber, FMSG_WARNING|FMSG_MB_OK, HelpTopic, Msg, sizeof(Msg)/sizeof(Msg[0]), 0);
#endif
}


//////////////////////////////////////////////////////////////////////////////


int
FarEditor::SetPosition (const int Line, const int Pos)
{
    EditorSetPosition esp;
#if FARMANAGERVERSION_MAJOR==3
    esp.StructSize = sizeof (EditorSetPosition);
#endif

    esp.CurLine = Line;
    esp.CurPos = Pos;
    esp.CurTabPos = -1;
    esp.TopScreenLine = -1;
    esp.LeftPos = -1;
    esp.Overtype = -1;

    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_SETPOSITION, 0, (void*)&esp);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_SETPOSITION, &esp);
#endif
    return ret;
}

int
FarEditor::GetPosition (int * Line, int * Pos)
{
    EditorInfo ei;
#if FARMANAGERVERSION_MAJOR==3
    ei.StructSize = sizeof (EditorInfo);
#endif

    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_GETINFO, 0, (void*)&ei);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_GETINFO, &ei);
#endif

    if (Line)
        *Line = ei.CurLine;
    if (Pos)
        *Pos = ei.CurPos;
    return ret;
}

int
FarEditor::GetTopScreenLine (int * TopScreenLine)
{
    EditorInfo ei;
#if FARMANAGERVERSION_MAJOR==3
    ei.StructSize = sizeof (EditorInfo);
#endif

    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_GETINFO, 0, (void*)&ei);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_GETINFO, &ei);
#endif

    if (TopScreenLine)
        *TopScreenLine = ei.TopScreenLine;
    return ret;
}

int
FarEditor::SetTitle (const wchar_t * s)
{
    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_SETTITLE, 0, const_cast<wchar_t*> (s));
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_SETTITLE, const_cast<wchar_t*> (s));
#endif
    return ret;
}

int
FarEditor::DeleteChar (void)
{
    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_DELETECHAR, 0, NULL);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_DELETECHAR, NULL);
#endif
    return ret;
}

int
FarEditor::InsertText (const wchar_t * s)
{
    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_INSERTTEXT, 0, const_cast<wchar_t*> (s));
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_INSERTTEXT, const_cast<wchar_t*> (s));
#endif
    return ret;
}

int
FarEditor::Redraw (void)
{
    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_REDRAW, 0, 0);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_REDRAW, 0);
#endif
    return ret;
}

int
FarEditor::GetString (EditorGetString *egs)
{
    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_GETSTRING, 0, egs);  // ���������� egs.StringText
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_GETSTRING, egs);  // ���������� egs.StringText
#endif
    return ret;
}

int
FarEditor::GetInfo (EditorInfo *ei)
{
    int ret =
#if FARMANAGERVERSION_MAJOR==3
        FarTools::Info.EditorControl (-1, ECTL_GETINFO, 0, ei);
#elif FARMANAGERVERSION_MAJOR==2
        FarTools::Info.EditorControl (ECTL_GETINFO, ei);
#endif
    return ret;
}

void
FarEditor::SetLeftTop (const int Line, const int Pos)
{
    EditorSetPosition esp;
#if FARMANAGERVERSION_MAJOR==3
    esp.StructSize = sizeof (EditorSetPosition);
#endif

    esp.CurLine = -1;
    esp.CurPos = -1;
    esp.CurTabPos = -1;
    esp.TopScreenLine = Line;
    esp.LeftPos = Pos;
    esp.Overtype = -1;

#if FARMANAGERVERSION_MAJOR==3
    FarTools::Info.EditorControl (-1, ECTL_SETPOSITION, 0, (void*)&esp);
#elif FARMANAGERVERSION_MAJOR==2
    FarTools::Info.EditorControl (ECTL_SETPOSITION, &esp);
#endif
}



void
FarEditor::mark_word_on (const int Line, const int Pos, const int N)
{
    EditorSelect es;
#if FARMANAGERVERSION_MAJOR==3
    es.StructSize = sizeof (EditorSelect);
#endif

    es.BlockType = BTYPE_STREAM;
    es.BlockStartLine = Line;
    es.BlockStartPos = Pos;
    es.BlockWidth = N;
    es.BlockHeight = 1;

#if FARMANAGERVERSION_MAJOR==3
    FarTools::Info.EditorControl (-1, ECTL_SELECT, 0, (void*)&es);
#elif FARMANAGERVERSION_MAJOR==2
    FarTools::Info.EditorControl (ECTL_SELECT, (void*)&es);
#endif

    // ����� ��?
    FarEditor::Redraw ();
}

void
FarEditor::mark_word_off (void)
{
    EditorSelect es;
#if FARMANAGERVERSION_MAJOR==3
    es.StructSize = sizeof (EditorSelect);
#endif

    es.BlockType = BTYPE_NONE;
    es.BlockStartLine = -1;
    es.BlockStartPos = -1;
    es.BlockWidth = -1;
    es.BlockHeight = -1;

#if FARMANAGERVERSION_MAJOR==3
    FarTools::Info.EditorControl (-1, ECTL_SELECT, 0, (void*)&es);
#elif FARMANAGERVERSION_MAJOR==2
    FarTools::Info.EditorControl (ECTL_SELECT, (void*)&es);
    FarTools::Info.EditorControl (ECTL_TURNOFFMARKINGBLOCK, NULL);
#endif

    // ����� ��?
    FarEditor::Redraw ();
}

int
FarEditor::get_cur_line_num (void)
{
    EditorInfo ei;
#if FARMANAGERVERSION_MAJOR==3
    ei.StructSize = sizeof (EditorInfo);
#endif

#if FARMANAGERVERSION_MAJOR==3
    FarTools::Info.EditorControl (-1, ECTL_GETINFO, 0, &ei);
#elif FARMANAGERVERSION_MAJOR==2
    FarTools::Info.EditorControl (ECTL_GETINFO, &ei);
#endif
    return ei.CurLine;
}
