#ifndef __FAR_TOOLS__HPP__
#define __FAR_TOOLS__HPP__

#include "far.hpp"


////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////
// Far 2 ������ ��������� �������� � ������� Windows

#if FARMANAGERVERSION_MAJOR==2

#include <windows.h>

const wchar_t * GetSubKey (void);

LONG CreateKey (HKEY *hKey);
LONG OpenKey (HKEY *hKey);

bool SetRegKey (const wchar_t * lpValueName, const bool value);
bool SetRegKey (const wchar_t * lpValueName, const wchar_t * value);

void GetRegKey (const wchar_t * lpValueName, bool *value, const bool def);
void GetRegKey (const wchar_t * lpValueName, wchar_t *value, const size_t mx, const wchar_t *def);

#endif



////////////////////////////////////////////////////////////////////////
// ����� ������� Far

class FarTools {
public:
    // ����������� � SetStartupInfoW
    static PluginStartupInfo Info;
    static FarStandardFunctions FSF;

public:
    static const wchar_t * GetMsg (const int message_id);

public:
    static int GetScreenHeight (void);
    static int GetScreenWidth (void);

    static int Menu (const int X, const int Y, const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2);
    static int Menu (const int X, const int Y, const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2, const wchar_t * S3);
    static int Menu (const int X, const int Y, const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2, const wchar_t * S3, const wchar_t * S4);

    static int Menu (const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2)
      { return Menu (-1, -1, Title, HelpTopic, S1, S2); }
    static int Menu (const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2, const wchar_t * S3)
      { return Menu (-1, -1, Title, HelpTopic, S1, S2, S3); }
    static int Menu (const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2, const wchar_t * S3, const wchar_t * S4)
      { return Menu (-1, -1, Title, HelpTopic, S1, S2, S3, S4); }

    static int MsgError (const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1);
    static int MsgError (const wchar_t * Title, const wchar_t * HelpTopic, const wchar_t * S1, const wchar_t * S2);

public:
    static int LIsAlpha (wchar_t c) { return Info.FSF->LIsAlpha (c); }
    static int LIsLower (wchar_t c) { return Info.FSF->LIsLower (c); }
    static int LIsUpper (wchar_t c) { return Info.FSF->LIsUpper (c); }
    static void Unquote (wchar_t *s) { Info.FSF->Unquote (s); }
    static wchar_t LLower (wchar_t c) { return Info.FSF->LLower (c); }
    static wchar_t LUpper (wchar_t c) { return Info.FSF->LUpper (c); }
/*
    static int snprintf (wchar_t *buf, size_t bufsize, const wchar_t *format, ...)
    {
	va_list argptr;
	va_start(argptr, Format);
	int Result =  _vsnwprintf(Dest, Count, Format, argptr);
	va_end(argptr);
	return Result;
    }
*/
/*
Info.FSF->snprintf
*/
};



////////////////////////////////////////////////////////////////////////
// ������� ��������� Far

class FarEditor {
public:
    static int SetPosition (const int Line, const int Pos);
    static int GetPosition (int * Line, int * Pos);
    static int GetTopScreenLine (int * TopScreenLine);

    static int SetTitle (const wchar_t * s);
    static int DeleteChar (void);
    static int InsertText (const wchar_t * s);
    static int Redraw (void);
    static int GetString (EditorGetString *egs);
    static int GetInfo (EditorInfo *ei);

    static void SetLeftTop (const int Line, const int Pos);

public:
    static void mark_word_on (const int Line, const int Pos, const int N);
    static void mark_word_off (void);

    static int get_cur_line_num (void);
};


#endif
