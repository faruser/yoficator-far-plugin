#include "mylog.hpp"

FILE * MyLog::os = NULL;
char   MyLog::file_name [MYLOG_FILENAME_BUF_SIZE];
bool   MyLog::is_bol = true;
size_t MyLog::counter = 0;
char * MyLog::default_file_name = "C:\\MyLog.log";
