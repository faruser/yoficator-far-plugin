#ifndef __MY_LOG__HPP__
#define __MY_LOG__HPP__

#include <cstdio>
#include <cstring>

#define MYLOG_FILENAME_BUF_SIZE 1024

class MyLog {
public:
    MyLog (const char * const file)
    {
//if (os) fprintf (os, "MyLog::MyLog (%s) begin\n", file);
        if (!(file && *file))
            return;

        if (
            0 == counter
            ||
            strcmp (file_name, file) != 0
        )
        {
            strcpy (file_name, file);
            if (os)
                fclose (os);
            os = fopen (file_name, "a");
//fprintf (os, "MyLog::MyLog: (re)open os for %s\n", file_name);
        }

        is_bol = true;
        ++counter;
//fprintf (os, "MyLog::MyLog (%s) end; counter = %d\n", file, counter);
    }
    MyLog ()
    {
//if (os) fprintf (os, "MyLog::MyLog() begin\n");
        if (0 == counter)
        {
            strcpy (file_name, default_file_name);
            if (os)
                fclose (os);
            os = fopen (file_name, "a");
//fprintf (os, "MyLog::MyLog() (re)open os for %s\n", file_name);
        }

        is_bol = true;
        ++counter;
//fprintf (os, "MyLog::MyLog() end, counter = %d\n", counter);
    }
    ~MyLog ()
    {
//fprintf (os, "MyLog::~MyLog() begin\n");
        if (counter > 0)
            --counter;
//fprintf (os, "MyLog::~MyLog() counter == %d\n", counter);
        if (0 == counter)
        {
//fprintf (os, "MyLog::~MyLog() (MyLog::os = NULL) is %s\n", (os ? "false" : "true"));
            if (os)
{
//fprintf (os, "MyLog::~MyLog() fclose(os)\n");
                fclose(os);
}
            os = NULL;
        }
//if (os) fprintf (os, "MyLog::~MyLog() end\n");
    }
private:
    static FILE * os;
private:
    static char file_name [MYLOG_FILENAME_BUF_SIZE];
    static bool is_bol;
    static size_t counter;
private:
    static char * default_file_name;
public:
    MyLog & operator << (bool b)          { new_line (); if (os) fprintf (os, "%s", (b ? "true" : "false")); return *this; }

    MyLog & operator << (int n)           { new_line (); if (os) fprintf (os, "%d", n); return *this; }
    MyLog & operator << (size_t n)        { new_line (); if (os) fprintf (os, "%u", n); return *this; }
    MyLog & operator << (long n)          { new_line (); if (os) fprintf (os, "%li", n); return *this; }
    MyLog & operator << (unsigned long n) { new_line (); if (os) fprintf (os, "%lu", n); return *this; }

    MyLog & operator << (char c)          { new_line (); if (os) fprintf (os, "%c", c); if ('\n' == c) is_bol = true; return *this; }
    MyLog & operator << (signed char c)   { new_line (); if (os) fprintf (os, "%c", c); if ('\n' == c) is_bol = true; return *this; }
    MyLog & operator << (unsigned char c) { new_line (); if (os) fprintf (os, "%c", c); if ('\n' == c) is_bol = true; return *this; }

    MyLog & operator << (const char * const s)          { new_line (); for (size_t i = 0; s[i]; ++i) *this << s[i]; return *this; }
    MyLog & operator << (const signed char * const s)   { new_line (); for (size_t i = 0; s[i]; ++i) *this << s[i]; return *this; }
    MyLog & operator << (const unsigned char * const s) { new_line (); for (size_t i = 0; s[i]; ++i) *this << s[i]; return *this; }
private:
    void new_line (void)
    {
        if (is_bol)
        {
            is_bol = false;
            for (size_t i = 1; i < counter; ++i)
                fprintf (os, "|  ");
        }
    }
};


#endif
