#include "yoficator.hpp"
#include "far_tools.hpp"


static bool
expand_env (wchar_t *s, const unsigned int l)
{
    DWORD r = ExpandEnvironmentStrings (s, NULL, 0);
    if (r && r <= l)
    {
        wchar_t * t = new wchar_t [r];
        if (t)
        {
            ExpandEnvironmentStrings (s, t, r);
            wcscpy (s, t);
            delete[] t;
            return true;
        }
    }
    return false;
}


void
norm_filename (wchar_t *s, const unsigned int l)
{
    expand_env (s, l);
    FarTools::Unquote (s);
}
