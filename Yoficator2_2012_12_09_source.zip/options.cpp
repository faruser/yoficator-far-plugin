#include "options.hpp"
#include "far.hpp"
#include "far_tools.hpp"


Options Opt;

bool
Options::Read (void)
{
#if FARMANAGERVERSION_MAJOR==3
    PluginSettings settings (MainGuid, FarTools::Info.SettingsControl);

    check_exist = settings.Get (0, L"CheckExist", true);
    confirm_all = settings.Get (0, L"ConfirmAll", false);

    settings.Get (0, L"DictFile", dict_file, ARRAYSIZE(dict_file), L"");
    settings.Get (0, L"UserDictFile", user_dict_file, ARRAYSIZE(user_dict_file), L"");
#elif FARMANAGERVERSION_MAJOR==2
    GetRegKey (L"ConfirmAll", &confirm_all, false);
    GetRegKey (L"CheckExist", &check_exist, true);

    GetRegKey (L"DictFile", dict_file, DICT_FILE_NAME_LENGTH, NULL);
    GetRegKey (L"UserDictFile", user_dict_file, DICT_FILE_NAME_LENGTH, NULL);
#endif

//  norm_filename (dict_file, DICT_FILE_NAME_LENGTH);
//  norm_filename (user_dict_file, DICT_FILE_NAME_LENGTH);
    return true;
}

bool
Options::Write (void)
{
#if FARMANAGERVERSION_MAJOR==3
    PluginSettings settings (MainGuid, FarTools::Info.SettingsControl);

    settings.Set (0, L"ConfirmAll", confirm_all);
    settings.Set (0, L"CheckExist", check_exist);

    settings.Set (0, L"DictFile", dict_file);
    settings.Set (0, L"UserDictFile", user_dict_file);
#elif FARMANAGERVERSION_MAJOR==2
    SetRegKey (L"ConfirmAll", confirm_all);
    SetRegKey (L"CheckExist", check_exist);

    SetRegKey (L"DictFile", dict_file);
    SetRegKey (L"UserDictFile", user_dict_file);
#endif

    return true;
}
