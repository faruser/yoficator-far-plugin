#ifndef __OPTIONS_HPP__
#define __OPTIONS_HPP__

// DICT_FILE_NAME_LENGTH
#include "yoficator.hpp"

struct Options {
    wchar_t dict_file[DICT_FILE_NAME_LENGTH];
    wchar_t user_dict_file[DICT_FILE_NAME_LENGTH];
    bool confirm_all;
    bool check_exist;
public:
    bool Read (void);
    bool Write (void);
};

extern Options Opt;

#endif
