#ifndef __UNICODE__HPP__
#define __UNICODE__HPP__

wchar_t windows1251_to_unicode (const wchar_t c);
unsigned char unicode_to_windows1251 (const wchar_t c);
bool is_rus (const wchar_t c);

#endif
