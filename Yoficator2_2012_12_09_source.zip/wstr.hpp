#ifndef __WSTR__HPP__
#define __WSTR__HPP__

#include <cstring>

class wstr {
public:
    wstr ()
    {
        wstr_s = 0;
        wstr_n = 0;
    }
    wstr (const wstr& s)
    {
        init (s.wstr_s, s.wstr_n);
    }
    wstr (const wchar_t * const s)
    {
        init (s, wcslen (s));
    }
    wstr (const wchar_t * const s, const size_t n)
    {
        init (s, n);
    }
    wstr (const wstr & s, const size_t n)
    {
        init (s.c_str (), n);
    }
    wstr (const size_t n, const wchar_t c)
    {
        if (0 == n)
        {
            wstr_s = 0;
            wstr_n = 0;
        }
        else
        {
            wstr_n = 0;
            wstr_s = new wchar_t [n + 1];
            if (wstr_s)
            {
                wstr_s[wstr_n = n] = 0;
                for (size_t i = 0; i < wstr_n; ++i)
                    wstr_s[i] = c;
            }
        }
    }
    ~wstr ()
    {
        delete[] wstr_s;
        wstr_s = 0;
        wstr_n = 0;
    }
public:
    wstr & operator= (const wstr& s)
    {
        re_init (s.wstr_s, s.wstr_n);
        return *this;
    }
    wstr & operator= (const wchar_t * const s)
    {
        re_init (s, wcslen (s));
        return *this;
    }
    wstr & operator= (const wchar_t c)
    {
        wchar_t t[2];
        t[0] = c;
        t[1] = 0;
        re_init (t, 1);
        return *this;
    }
public:
    wstr & operator += (const wstr & s)
    {
        if (0 == s.wstr_n)
            return *this;

        wchar_t * p = new wchar_t [wstr_n + s.wstr_n + 1];
        if (p)
        {
            if (wstr_s)
            {
                wcscpy (p, wstr_s);
                wcscat (p, s.wstr_s);
            }
            else
            {
                wcscpy (p, s.wstr_s);
            }
            delete[] wstr_s;
            wstr_s = p;
            wstr_n += s.wstr_n;
        }
        return *this;
    }
    wstr & operator += (const wchar_t * s)
    {
        if (!s || !(s[0]))
            return *this;

        size_t l = wcslen (s);
        wchar_t * p = new wchar_t [wstr_n + l + 1];
        if (p)
        {
            if (wstr_s)
            {
                wcscpy (p, wstr_s);
                wcscat (p, s);
            }
            else
            {
                wcscpy (p, s);
            }
            delete[] wstr_s;
            wstr_s = p;
            wstr_n += l;
        }
        return *this;
    }
    wstr & operator += (const wchar_t c)
    {
        wchar_t * p = new wchar_t [wstr_n + 1 + 1];
        if (p)
        {
            if (wstr_s)
                wcscpy (p, wstr_s);
            p[wstr_n] = c;
            p[wstr_n+1] = 0;
            delete[] wstr_s;
            wstr_s = p;
            ++wstr_n;
        }
        return *this;
    }
public:
    friend wstr operator+ (const wstr & s1, const wstr & s2)
    {
        wstr t (s1);
        return t += s2;
    }
    friend wstr operator+ (const wchar_t * s1, const wstr & s2)
    {
        wstr t (s1);
        return t += s2;
    }
    friend wstr operator+ (const wchar_t c, const wstr & s)
    {
        wstr t (1, c);
        return t += s;
    }
    friend wstr operator+ (const wstr & s1, const wchar_t * s2)
    {
        wstr t (s1);
        return t += wstr (s2);
    }
    friend wstr operator+ (const wstr & s, const wchar_t c)
    {
        wstr t (s);
        return t += wstr (1, c);
    }
public:
    // ������ � ���������
    const wchar_t & operator[] (const size_t n) const { return wstr_s[n]; }
          wchar_t & operator[] (const size_t n)       { return wstr_s[n]; }
public:
    // ����� ������
    size_t length (void) const { return wstr_n; }
    // ������
    const wchar_t * c_str (void) const { return wstr_s; }
    // ������?
    bool empty (void) const { return 0 == wstr_n; }
private:
    wchar_t * wstr_s;
    size_t wstr_n;  // not including '\0'
private:
    void init (const wchar_t * const s, const size_t n)
    {
        wstr_s = 0;
        wstr_n = 0;

        if (s)
        {
            wstr_s = new wchar_t [n + 1];
            if (wstr_s)
            {
                wstr_n = n;
                wcsncpy (wstr_s, s, wstr_n);
                wstr_s[wstr_n] = 0;
            }
        }
    }
    void re_init (const wchar_t * const s, const size_t n)
    {
        if (!s)
        {
            delete[] wstr_s;
            wstr_s = 0;
            wstr_n = 0;
        }
        else
        {
            wchar_t * t = new wchar_t [n + 1];
            if (t)
            {
                delete[] wstr_s;
                wstr_s = t;

                wstr_n = n;
                wcsncpy (wstr_s, s, wstr_n);
                wstr_s[wstr_n] = 0;
            }
        }
    }
};

#endif
