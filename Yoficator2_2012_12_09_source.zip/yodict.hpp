#ifndef __YODICT_HPP__
#define __YODICT_HPP__

//#include <vector>  // ��� ������� � ������
//#include <deque>   // ertr000001.o:(.rdata+0x0): undefined reference to `_pei386_runtime_relocator' ��� ��������
#include <list>

#include "wstr.hpp"
using namespace std;


// ���� ��������
const wchar_t Yo_Upper = 1025;
const wchar_t Yo_Lower = 1105;
const wchar_t E_Upper = 1045;
const wchar_t E_Lower = 1077;


class DictWord
{
public:
    wstr word;
    bool confirm;
public:
    DictWord (void) {}
    DictWord (const wchar_t * const w)
    {
        size_t l = wcslen (w);
        confirm = (w[l-1] == L'?');
        if (confirm)
            word = wstr (w, l-1);
        else
            word = w;
    }
    ~DictWord () {}
public:
    DictWord & operator= (const wchar_t * const w)
    {
        size_t l = wcslen (w);
        confirm = (w[l-1] == L'?');
        if (confirm)
            word = wstr (w, l-1);
        else
            word = w;
        return *this;
    }
public:
    const wchar_t * str (void) const
    {
        return word.c_str ();
    }
};


class Yodict
{
public:
    // ������������ ����� ����� � �������
    static const int MAX_WORD_LEN = 127;
    // ���� ������
    static const int ERR_FILE_READ = -1;
public:
    Yodict () {}
    ~Yodict () {}
public:
    long read_dict (const wchar_t * file);
public:
    void push_front (const wchar_t * w) { dict.push_front (DictWord (w)); }
    void push_front (const wstr & w)    { dict.push_front (DictWord (w.c_str ())); }
    void push_back (const wchar_t * w)  { dict.push_back (DictWord (w)); }
    void push_back (const wstr & w)     { dict.push_back (DictWord (w.c_str ())); }
public:
    const wchar_t * FindWordInDict (const wchar_t * const Word, bool & Confirm) const;
public:
    // ����� �������
    list<DictWord> dict;
};

#endif  /// __YODICT_HPP__
