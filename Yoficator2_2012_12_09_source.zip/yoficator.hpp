#ifndef __YOFICATOR_HPP__
#define __YOFICATOR_HPP__

// size_t
#include <stddef.h>

// Yodict
#include "yodict.hpp"


const size_t DICT_FILE_NAME_LENGTH = 256;

void yoficator (void);

void norm_filename (wchar_t *s, const unsigned int l);
bool set_starting_pos (void);
bool check_for_esc (void);

bool parse_word (const wchar_t * const Str, const size_t Pos, const size_t Len, Yodict & Dict, bool * UserBreak);

int diff_pos (const wchar_t * Word1, const wchar_t * Word2);
void replace_char (const size_t Pos, const wchar_t c);
void center_word (const int Pos, const int Len);
size_t yo_dialog (const wchar_t * Word1, const wchar_t * Word2, bool * UserBreak, size_t * EPos);
bool find_word (const wchar_t * const Str, size_t * const Pos, size_t * const Len, bool * const UserBreak);

wstr make_word_e (const wchar_t * Word1, const wchar_t * Word2);
wstr make_word_yo (const wchar_t * Word1, const wchar_t * Word2);


#endif
